package highscore;

public class HighScoreException extends Exception{

    public HighScoreException(){}

    public HighScoreException(String ex){
        super(ex);
    }

}

