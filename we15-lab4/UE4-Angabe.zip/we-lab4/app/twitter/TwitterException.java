package twitter;

public class TwitterException extends Exception{
	
	public TwitterException(){
		
	}
	
	public TwitterException(String exception){
		super(exception);
	}

}
